// /data/learn/index.ts
export * as cpp from "./cpp";
export * as devops from "./devops";
export * as c from "./c"
export * as git from "./git"
export * as py from "./python"